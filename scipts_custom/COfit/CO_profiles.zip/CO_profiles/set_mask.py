import numpy as np
import matplotlib.pyplot as plt
from tifffile.tifffile import asbool

s12 = np.loadtxt('./C12.dat')
s13 = np.loadtxt('./C13.dat')
s18 = np.loadtxt('./C18.dat')

mask = np.ones((len(s12[:,0]),2))
mask[:,0] = s12[:,0]
mask[:,1][s12[:,1]<0.995] = 0
mask[:,1][s13[:,1]<0.995] = 0
mask[:,1][s18[:,1]<0.995] = 0
mask[:,1] = np.array(mask[:,1], dtype=bool)
plt.subplots()
plt.plot(s12[:,0],s12[:,1])
plt.plot(s13[:,0],s13[:,1])
plt.plot(s18[:,0],s18[:,1])

plt.plot(mask[:,0],mask[:,1],'-')


plt.show()

np.savetxt('./mask_CO.dat',mask)